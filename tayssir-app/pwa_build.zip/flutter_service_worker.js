'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "019c3631fe014e4980181c25154cd10c",
"version.json": "cf2f316540e486e8e8139f980ffde04e",
"index.html": "0414cb4dd41e751b2881b8a24948743b",
"/": "0414cb4dd41e751b2881b8a24948743b",
"firebase-messaging-sw.js": "c64ea609572a0e3764949433cdaa903e",
"main.dart.js": "c59061655038e9a8bd5f8d346c84d1db",
"flutter.js": "83d881c1dbb6d6bcd6b42e274605b69c",
"favicon.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/TayssirIcon-512.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/Icon-192.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/Icon-maskable-192.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/TayssirIcon-192.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/Icon-maskable-512.png": "c137b9cf7bea48a3d48106405e8603a4",
"icons/Icon-512.png": "c137b9cf7bea48a3d48106405e8603a4",
"manifest.json": "deff7fab1d9fb11673bcac09cf54c614",
"assets/AssetManifest.json": "de2533bd94556123f7b568fd1fc9c9d5",
"assets/NOTICES": "a95238e73a4002c5c3c09f78dfaf5248",
"assets/FontManifest.json": "9eb2e3da73823c6356b6d1ba57c5efa5",
"assets/AssetManifest.bin.json": "849b29088f8510c9655daed16de5a7de",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_AMS-Regular.ttf": "657a5353a553777e270827bd1630e467",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Script-Regular.ttf": "55d2dcd4778875a53ff09320a85a5296",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size3-Regular.ttf": "e87212c26bb86c21eb028aba2ac53ec3",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Typewriter-Regular.ttf": "87f56927f1ba726ce0591955c8b3b42d",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Caligraphic-Bold.ttf": "a9c8e437146ef63fcd6fae7cf65ca859",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Bold.ttf": "ad0a28f28f736cf4c121bcb0e719b88a",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Bold.ttf": "9eef86c1f9efa78ab93d41a0551948f7",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Fraktur-Regular.ttf": "dede6f2c7dad4402fa205644391b3a94",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Regular.ttf": "5a5766c715ee765aa1398997643f1589",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Italic.ttf": "d89b80e7bdd57d238eeaa80ed9a1013a",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Math-Italic.ttf": "a7732ecb5840a15be39e1eda377bc21d",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Italic.ttf": "ac3b1882325add4f148f05db8cafd401",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Fraktur-Bold.ttf": "46b41c4de7a936d099575185a94855c4",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size2-Regular.ttf": "959972785387fe35f7d47dbfb0385bc4",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Regular.ttf": "b5f967ed9e4933f1c3165a12fe3436df",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size1-Regular.ttf": "1e6a3368d660edc3a2fbbe72edfeaa85",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Caligraphic-Regular.ttf": "7ec92adfa4fe03eb8e9bfb60813df1fa",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size4-Regular.ttf": "85554307b465da7eb785fd3ce52ad282",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-BoldItalic.ttf": "e3c361ea8d1c215805439ce0941a1c8d",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Math-BoldItalic.ttf": "946a26954ab7fbd7ea78df07795a6cbc",
"assets/packages/awesome_snackbar_content/assets/types/warning.svg": "cfcc5fcb570129febe890f2e117615e0",
"assets/packages/awesome_snackbar_content/assets/types/failure.svg": "cb9e759ee55687836e9c1f20480dd9c8",
"assets/packages/awesome_snackbar_content/assets/types/success.svg": "6e273a8f41cd45839b2e3a36747189ac",
"assets/packages/awesome_snackbar_content/assets/types/help.svg": "7fb350b5c30bde7deeb3160f591461ff",
"assets/packages/awesome_snackbar_content/assets/back.svg": "ba1c3aebba280f23f5509bd42dab958d",
"assets/packages/awesome_snackbar_content/assets/bubbles.svg": "1df6817bf509ee4e615fe821bc6dabd9",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/packages/iconsax_flutter/fonts/FlutterIconsax.ttf": "6ebc7bc5b74956596611c6774d8beb5b",
"assets/packages/flutter_tex/core/mathjax_core.js": "9b5f306485385a5a7519247602d50c24",
"assets/packages/flutter_tex/core/flutter_tex.html": "c281d36e549d9b8422f043ae45437d41",
"assets/packages/flutter_tex/core/flutter_tex.css": "062a3279da48d0913eeeeb0d2266e26f",
"assets/packages/flutter_tex/core/flutter_tex.js": "7cd72377628156a02d872e8e179375be",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin": "e0947958e14816e1c5b2cd5b660be81b",
"assets/fonts/MaterialIcons-Regular.otf": "0a8ce1674af138acedbf1189666cd3a2",
"assets/assets/svg/ic_phone.svg": "1f41f9c91b2a776a6b020c57017adc01",
"assets/assets/svg/grid.svg": "c5b50fb741ddb17f5fdd88478dee62e5",
"assets/assets/svg/list.svg": "1a0d6a7f36b4512957ff30cb9f3cae97",
"assets/assets/svg/ic_time.svg": "7b7f036cd810776dd17b1092165012d5",
"assets/assets/svg/tito_pomodoro_stop.svg": "7036c0fe2c1977a12be1ae3ccacfff15",
"assets/assets/svg/ic_facebook.svg": "ecdd6bc55a0c23cf3243108684bcf9f7",
"assets/assets/svg/tito_bad.svg": "9f2dcedc6e5e762edfc0d60b37d5ad5f",
"assets/assets/svg/ccp.svg": "1ddb682a646226882e8fba582d04729a",
"assets/assets/svg/good_tito.svg": "0426f818e70958bee3557a59200d5ae6",
"assets/assets/svg/tito_average.svg": "628005d41e399d432a2c6cb6d4ed8feb",
"assets/assets/svg/ic_result_check.svg": "ffcc58d99770e8526b3a97a025cf77c6",
"assets/assets/svg/ic_security.svg": "fe2770df1f4a0846b31849f72cf12217",
"assets/assets/svg/ic_tiktok.svg": "4ccb0d30f04038a2d182630aea29405a",
"assets/assets/svg/tito_perfect.svg": "2dbe80323a35e83f4c86179d996293ee",
"assets/assets/svg/ic_algerie_poste.svg": "1ddb682a646226882e8fba582d04729a",
"assets/assets/svg/tito_average_message.svg": "e08dbf31fcfb23aaa5cb3b01bd9f1e69",
"assets/assets/svg/ic_barid_mob.svg": "03fba045786ffa191636cc6a4e0cb114",
"assets/assets/svg/ic_philo.svg": "81ef8a5d32d52d9e41c3f2ed1eb9d0ee",
"assets/assets/svg/ic_precision.svg": "949424446459c1b74beeda81074216a3",
"assets/assets/svg/ic_baridi.svg": "ab53560829696aa6726c53a2f3c71be2",
"assets/assets/svg/ic_leaderboard.svg": "17db59f7b89eb30347f2340aecef470c",
"assets/assets/svg/ic_home.svg": "a41a868e0464f385d97c30deffb230f6",
"assets/assets/svg/ic_perfect_achievement.svg": "04adbc80d9749c5b7adc32ff35fc283d",
"assets/assets/svg/ic_race.svg": "95369ace32f704c82ecc4926be5cf40b",
"assets/assets/svg/instagram.svg": "65f78e872f2f54d22d80fdcdb77ed1f9",
"assets/assets/svg/ic_content_creator.svg": "f6bd61069d1ac3f3db0cf8d2935403e5",
"assets/assets/svg/ic_duolingo.svg": "450988f819fa39f81bf404b8d15d94d0",
"assets/assets/svg/ic_card_logo.svg": "b8937031f878aec78876d4105923cc2c",
"assets/assets/svg/ic_lessons_achievement.svg": "5d8bdd9682c82f7bde9c92f415287eff",
"assets/assets/svg/ic_gestion.svg": "44b1cb1324e9b66d03da13b65fc6dbba",
"assets/assets/svg/telegram.svg": "b9e129b622a02d0967811802b0a47105",
"assets/assets/svg/Tito_login.svg": "ec9739117fee4f530b96a721f7bf00dd",
"assets/assets/svg/ic_youtube.svg": "3bb63286012844cbf0681c572e5ecf2a",
"assets/assets/svg/tito_subscription_good.svg": "a436051a79d4fd70d8c9a93335351a8d",
"assets/assets/svg/ic_calc.svg": "717f860341a6e71c60c50a08bf11951f",
"assets/assets/svg/ic_building.svg": "4ff819ee71112d4a8eefac4674a134f3",
"assets/assets/svg/ic_birthday.svg": "341d90affd315cab2f995069418a00da",
"assets/assets/svg/ic_google.svg": "da772f11bb2e68f525f11b09d61c2216",
"assets/assets/svg/ic_eye.svg": "e0697369a35df1d08c485255a662abab",
"assets/assets/svg/ic_langues.svg": "dcd83a6c59b31728552d1e4dc2e4a533",
"assets/assets/svg/tito_pomodoro_done.svg": "b68f88fc20550be47b745575fac3f27c",
"assets/assets/svg/tito_pomodoro_first.svg": "662a7f2d8c9b6e799310e15e38883f28",
"assets/assets/svg/Tito.svg": "361ec7a74da768c94aa7ac7643279443",
"assets/assets/svg/question_icon.svg": "41dbd498a9386bf6767f2ee426a13b33",
"assets/assets/svg/coming_soon.svg": "0b2edc09052fc1dd6cfe941f8517091e",
"assets/assets/svg/notification.svg": "4964bc95a0325c98b68c9e44d2c2c2c0",
"assets/assets/svg/ic_streak_achievement.svg": "d3a74dcf8da69f98402b77b023e3ce4a",
"assets/assets/svg/ic_flash.svg": "71f075352db38c55e13ed6be7a09bfe8",
"assets/assets/svg/ic_commune.svg": "07edc9cfc0aada4db5f2c802b4a3d0a6",
"assets/assets/svg/tito_good_exercise.svg": "e4139220df434569e02cab969f0cb01f",
"assets/assets/svg/latest_logo.svg": "dac688f5538505a2c5179b8b207ed829",
"assets/assets/svg/ic_teacher.svg": "bc8d4fa52235d2e61cd13a99a516cac2",
"assets/assets/svg/tito_susbscription_pending.svg": "5e69a04aea36b039900bb40040dec018",
"assets/assets/svg/ic_math.svg": "88a4ac0b9a4e19c3d462a350b4c2a43e",
"assets/assets/svg/tito_boarding.svg": "0bada220f9792d1bca3aa367f45338c2",
"assets/assets/svg/ic_science.svg": "8f546ca6d9b2ae4a0c34d172f5ad72a3",
"assets/assets/svg/youtube.svg": "50dbaeaa3c601883ec6345ed7fa04182",
"assets/assets/svg/ic_math_technique.svg": "a9648ecf9bdbed9d4b73d489ebab5bb8",
"assets/assets/svg/ic_person.svg": "e6f5e1dc2284f66026b2be8a05632ec2",
"assets/assets/svg/ic_question.svg": "8c26909423c01f1dd794833aa1763f04",
"assets/assets/svg/tito_good.svg": "7ade42830dafdf9039f0b23d9a2104e9",
"assets/assets/svg/ic_sound.svg": "4c236ebfd4955505ba0e88b3f220e189",
"assets/assets/svg/ic_specitlity.svg": "4a2daacd5085202f0fa12a99bd3e258d",
"assets/assets/svg/tito_bad_message.svg": "a5327d830cf982c0318757558ffc2c9d",
"assets/assets/svg/ic_points_achievement.svg": "4bceedd905249a008669609ce4ea88d1",
"assets/assets/svg/ic_tito_progress.svg": "d82949120edb88c1109f9877705a7a52",
"assets/assets/svg/ic_settings.svg": "b6baacb58061e5e12be3b8ebccde63a1",
"assets/assets/svg/ic_box.svg": "6f8b7badb14fa22c92a8bab67fd3df76",
"assets/assets/svg/logo.svg": "aed56c1ed5754ed60d6b76f751a466a1",
"assets/assets/svg/tito_sub_failure.svg": "510d98f10575df43ee7d53666f7d8b1d",
"assets/assets/svg/ic_gem.svg": "4e7fe66fccb3aed1b15d1d538e746bcb",
"assets/assets/svg/tito_angry.svg": "9ddfd91451514a3fdc3ef8d4393caf0f",
"assets/assets/svg/ic_instagram.svg": "b9c32d48ab8e83730bd8a1fca530cb29",
"assets/assets/images/pomodoro_bg.png": "7c14b481bd5f3c9d6bc3c783e22b2b9b",
"assets/assets/images/resums_l_bg.png": "39b4b84c5a2437315085be53fa50bdb7",
"assets/assets/images/flash_cards_g_bg.png": "2f4b46bc1314108142956c770f3f98d2",
"assets/assets/images/sub_bg.png": "e2d7eae8ad1c1b0a68b3695df95b5950",
"assets/assets/images/achievement_share_bg.png": "277dbf8178ddad51056a7d2449f45ff5",
"assets/assets/images/failure_bg.png": "ab9be6bc0fe263016ce55e89923a812a",
"assets/assets/images/resumes_g_bg.png": "9233e7a799589acbf3d7cd6d58c45deb",
"assets/assets/images/pomodoro_bg_list.png": "d836c5f2e634454b10f4dd2b606fd1f2",
"assets/assets/images/resolve_list_bg.png": "0b7641624d36d03648860cf1021dc30b",
"assets/assets/images/success_bg.png": "3aa154456b580f667daa1d2158eb014b",
"assets/assets/images/reolve_grid_bg.png": "1dc36642a5f40a3636e1046b9513a259",
"assets/assets/images/grade_calc_list.png": "c466ed0d2e5d5003690e0499f2753bc2",
"assets/assets/images/flash_cards_l_bg.png": "18dec7c4fcaf4a4b9fc7332270d5986e",
"assets/assets/images/grade_calc_grid.png": "122abca1b38739b330daa8dda287d8ff",
"assets/assets/images/streak_share_bg.png": "628c580b41e26d2c953d142ade0293e9",
"assets/assets/sounds/match_found.mp3": "ad0ce5b10660cf01c04c1b5a564e68e0",
"assets/assets/sounds/level_complete.mp3": "b35646b363a10593a0993eec0f87acd4",
"assets/assets/sounds/task_done.mp3": "08f212560afaa087dcbcb627dd164921",
"assets/assets/sounds/ui_click_premium.mp3": "61be50e45892db158e07a17f0f91ee37",
"assets/assets/sounds/chat_pop.mp3": "13f5f129880ea7844f464d4e9fd42edb",
"assets/assets/sounds/streak_fire.mp3": "9f4d2b60f19f58edc3c4b94de73f2174",
"assets/assets/sounds/ai_magic.mp3": "7e4f210931fcead13a979974e7d2cf78",
"assets/assets/sounds/points_collect.mp3": "5f4d7ff5790cef139b575acc91377e5e",
"assets/assets/sounds/success_short.mp3": "741f4d28d73b347a003a7896750f37c2",
"assets/assets/sounds/error_soft.mp3": "ad25bf8234af9536ac81fa66f8db8953",
"assets/assets/sounds/action.mp3": "a3ed137dfc43db4aa4d32f2fb572f164",
"assets/assets/sounds/notification_ping.mp3": "2b2867bc0afb768c37dd99e5b2a4d457",
"assets/assets/sounds/ms_click.mp3": "3b45627df5812416a40087dbaded82c3",
"assets/assets/lottie/battle_intro.json": "9ae3a43331dbddde96bcd117f3529c25",
"assets/assets/fonts/SomarSans-ThinItalic.otf": "ced3950b9a418842bb6ca689549da4de",
"assets/assets/fonts/SomarSans-BoldItalic.otf": "85a2115949a10ddb540ffc67bcc64114",
"assets/assets/fonts/SomarSans-Light.otf": "464ebdf6e752aa1b616167e83a44ae2d",
"assets/assets/fonts/SomarSans-Regular.otf": "6b807c56139680c081e1a2c5c842541f",
"assets/assets/fonts/SomarSans-LightItalic.otf": "7496b77884570d19ca71b9aa3cf1087e",
"assets/assets/fonts/SomarSans-Bold.otf": "c6bb476f16362d2eedd41c437cb88b92",
"assets/assets/fonts/SomarSans-Black.otf": "42b1eafcb43c5483e46d53c9ee67eb14",
"assets/assets/fonts/SomarSans-RegularItalic.otf": "79b2a8ed7ba00b9e2976d7305611dfc8",
"assets/assets/fonts/SomarSans-BlackItalic.otf": "caeb84be48da485b0b15824b89be9f65",
"assets/assets/fonts/SomarSans-Thin.otf": "cd6e18cf8108ed9c9a5c27338da7e938",
"assets/assets/data/config.json": "7bb70f64d4b3943efc755f294e5fa371",
"favicon.svg": "361ec7a74da768c94aa7ac7643279443",
"flutter_bootstrap_diagnostic.js": "c4d6047aa072921216b5cc46b8d14064",
"canvaskit/skwasm.js": "ea559890a088fe28b4ddf70e17e60052",
"canvaskit/skwasm.js.symbols": "e72c79950c8a8483d826a7f0560573a1",
"canvaskit/canvaskit.js.symbols": "bdcd3835edf8586b6d6edfce8749fb77",
"canvaskit/skwasm.wasm": "39dd80367a4e71582d234948adc521c0",
"canvaskit/chromium/canvaskit.js.symbols": "b61b5f4673c9698029fa0a746a9ad581",
"canvaskit/chromium/canvaskit.js": "8191e843020c832c9cf8852a4b909d4c",
"canvaskit/chromium/canvaskit.wasm": "f504de372e31c8031018a9ec0a9ef5f0",
"canvaskit/canvaskit.js": "728b2d477d9b8c14593d4f9b82b484f3",
"canvaskit/canvaskit.wasm": "7a3f4ae7d65fc1de6a6e7ddd3224bc93"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
