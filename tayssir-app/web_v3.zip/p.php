<?php
// Tayssir Image Proxy - Enhanced Error Reporting
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Cache-Control: public, max-age=86400");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$img = $_GET['img'] ?? '';
if (!$img) {
    header("Content-Type: text/plain");
    die("Error: No image path provided. Usage: p.php?img=path/to/image.png");
}

// Security: Clean path
$img = str_replace(['../', '..\\'], '', $img);
$img = ltrim($img, '/');

// Targeted Storage URL
$storageBase = "https://291013.tayssir-bac.com/storage/";
$targetUrl = $storageBase . $img;

// Use cURL for better handling and timeout
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $targetUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0.4472.124 Safari/537.36");

$data = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if ($httpCode !== 200 || !$data) {
    header("HTTP/1.1 $httpCode Not Found");
    header("Content-Type: text/plain");
    echo "Proxy Error: Could not fetch image.\n";
    echo "HTTP Status: $httpCode\n";
    echo "Target URL: $targetUrl\n";
    exit;
}

// Forward the content type from the source if possible
if ($contentType) {
    header("Content-Type: $contentType");
} else {
    $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
    $mimes = ['png'=>'image/png', 'jpg'=>'image/jpeg', 'jpeg'=>'image/jpeg', 'svg'=>'image/svg+xml', 'webp'=>'image/webp'];
    header("Content-Type: " . ($mimes[$ext] ?? 'image/jpeg'));
}

echo $data;
